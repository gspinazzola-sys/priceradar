import { Category, Provider, Product } from './types';

export const CATEGORIES: Category[] = [
  { id: 'sofas', name: 'Sofas', icon: '🛋️', count: 12 },
  { id: 'betten', name: 'Betten', icon: '🛏️', count: 8 },
  { id: 'stuehle', name: 'Stühle', icon: '🪑', count: 15 },
  { id: 'tische', name: 'Tische', icon: '🪵', count: 9 },
];

export const DEMO_PRODUCTS: Product[] = [
  {
    id: 'sofa_lena',
    name: 'Sofa Lena 3-Sitzer',
    category: 'sofas',
    providersCount: 4,
    bestPrice: 749,
    lastSearched: 'Zuletzt: heute 08:32',
  },
  {
    id: 'malm_bett',
    name: 'Bett Malm 160x200',
    category: 'betten',
    providersCount: 3,
    bestPrice: 299,
    lastSearched: 'Zuletzt: gestern 14:15',
  },
  {
    id: 'nordmyra_chair',
    name: 'Holzstuhl Nordmyra',
    category: 'stuehle',
    providersCount: 5,
    bestPrice: 49,
    lastSearched: 'Zuletzt: heute 06:12',
  },
  {
    id: 'ingo_tisch',
    name: 'Esstisch Ingo',
    category: 'tische',
    providersCount: 2,
    bestPrice: 129,
    lastSearched: 'Zuletzt: vor 4 Tagen',
  },
];

export const PROVIDERS_FOR_SOFA: Provider[] = [
  {
    id: 'ikea',
    name: 'IKEA',
    price: 749,
    url: 'https://ikea.com/ch/de/p/friheten-eckbettsofa-3-sitzer-beige-60262369/',
    domain: 'ikea.ch',
    timestamp: 'Heute 09:01',
    badge: '🏆 Bestes Angebot',
    badgeType: 'best',
    borderClass: 'border-l-4 border-l-emerald-500 border-emerald-100',
  },
  {
    id: 'conforma',
    name: 'Conforma',
    price: 819,
    url: 'https://conforma.ch/de/sofa-lena-3-sitzer',
    domain: 'conforma.ch',
    timestamp: '⚠️ Vor 3 Tagen',
    badge: '⚠️ Veraltet?',
    badgeType: 'warning',
    borderClass: 'border-l-4 border-l-orange-500 border-orange-100',
  },
  {
    id: 'moebel_pfister_online',
    name: 'Möbel Pfister Online',
    price: 869,
    url: 'https://moebelshop.ch/sofas/lena-3-seater',
    domain: 'moebelshop.ch',
    timestamp: 'Heute 08:55',
    borderClass: 'border-l-4 border-l-slate-300 border-slate-100',
  },
  {
    id: 'pfister',
    name: 'Pfister',
    price: 899,
    url: 'https://pfister.ch/de/produkt/sofa-lena-3-sitzer',
    domain: 'pfister.ch',
    timestamp: 'Heute 09:01',
    badgeType: 'danger',
    borderClass: 'border-l-4 border-l-rose-500 border-rose-100',
  },
];

export const PROVIDER_DETAILS: Record<string, {
  shopName: string;
  price: number;
  productTitle: string;
  url: string;
  timeText: string;
  isFresh: boolean;
  colorTheme: string; // Header background color
  chartLabel: string;
}> = {
  ikea: {
    shopName: 'IKEA Schweiz',
    price: 749,
    productTitle: 'Sofa FRIHETEN, 3-Sitzer, beige',
    url: 'ikea.com/ch/de/friheten-eckbettsofa-beige',
    timeText: 'Heute 09:01 Uhr',
    isFresh: true,
    colorTheme: 'bg-emerald-800',
    chartLabel: '✅ Stabil bei CHF 749.– seit 7 Tagen',
  },
  conforma: {
    shopName: 'Conforma',
    price: 819,
    productTitle: '3-Sitzer Komfortsofa LENA, grau',
    url: 'conforma.ch/de/polsterecke-lena-3er',
    timeText: 'Vor 3 Tagen',
    isFresh: false,
    colorTheme: 'bg-amber-700',
    chartLabel: '⚠️ Letzte Änderung vor 3 Tagen gemeldet',
  },
  moebel_pfister_online: {
    shopName: 'Möbel Pfister Online',
    price: 869,
    productTitle: 'Polstersofa LENA (3-Sitzer)',
    url: 'moebelshop.ch/sofas/lena-3-sitzer-stoff',
    timeText: 'Heute 08:55 Uhr',
    isFresh: true,
    colorTheme: 'bg-slate-800',
    chartLabel: '✅ Preisanstieg um CHF 20 vor 2 Tagen',
  },
  pfister: {
    shopName: 'Pfister AG',
    price: 899,
    productTitle: 'Sofa LENA 3-Plätzer mit Stoffbezug',
    url: 'pfister.ch/de/produkt/sofa-lena-3-sitzer',
    timeText: 'Heute 09:01 Uhr',
    isFresh: true,
    colorTheme: 'bg-rose-950',
    chartLabel: '❌ Teuerster Anbieter (+20%) seit 5 Tagen',
  },
};
