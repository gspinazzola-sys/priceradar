/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Sparkles, 
  TrendingDown, 
  AlertTriangle, 
  ChevronLeft, 
  Plus, 
  Bell, 
  Settings, 
  Home, 
  Check, 
  CheckCircle, 
  ExternalLink, 
  AlertCircle, 
  Mail, 
  Info,
  Calendar,
  Share2,
  ArrowRight,
  TrendingUp,
  SlidersHorizontal,
  ThumbsUp,
  Sliders,
  DollarSign,
  Undo2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CATEGORIES, DEMO_PRODUCTS, PROVIDERS_FOR_SOFA, PROVIDER_DETAILS } from './data';
import { ScreenId, Provider, PriceAlert } from './types';

export default function App() {
  // Mobile app active state
  const [activeScreen, setActiveScreen] = useState<ScreenId>(1);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [lastSearchedProducts, setLastSearchedProducts] = useState(DEMO_PRODUCTS);
  
  // Filter & sorting states
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'cheapest' | 'newest'>('cheapest');
  
  // Selected provider for details view (Screen 3)
  const [selectedProviderId, setSelectedProviderId] = useState<string>('ikea');

  // Screen 4 States
  const [selectedActionId, setSelectedActionId] = useState<number>(2); // Default is pre-selected "Preisalarm setzen"
  const [wunschpreis, setWunschpreis] = useState<number>(680);
  const [emailInput, setEmailInput] = useState<string>('lena@mail.ch');

  // Saved alarms database for realistic mock interactivity
  const [alarms, setAlarms] = useState<PriceAlert[]>([
    {
      productName: 'Sofa Lena 3-Sitzer',
      targetPrice: 680,
      email: 'lena@mail.ch',
      status: 'Aktiv'
    }
  ]);
  
  // UI notifications
  const [notification, setNotification] = useState<string | null>(null);
  const [showAlarmsSheet, setShowAlarmsSheet] = useState<boolean>(false);

  // Auto clear notification
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Handle Search submit
  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    // Navigate to Screen 2
    setActiveScreen(2);
    triggerCelebratoryLog('Suchen nach: ' + (searchQuery || 'Sofa Lena 3-Sitzer'));
  };

  // Helper helper to print nice debug states in console
  const triggerCelebratoryLog = (msg: string) => {
    console.log(`[PriceRadar Prototype] ${msg}`);
  };

  // Handle category selection
  const selectCategory = (catId: string) => {
    setSelectedCategory(catId);
    setSearchQuery(catId === 'sofas' ? 'Sofa Lena 3-Sitzer' : '');
    setActiveScreen(2);
    setNotification(`Kategorie "${catId.toUpperCase()}" ausgewählt – Sofa Lena geladen!`);
  };

  // Save alarm logic 
  const handleSaveAlarm = () => {
    // Add current alarm to local state
    const newAlarm: PriceAlert = {
      productName: 'Sofa Lena 3-Sitzer',
      targetPrice: Number(wunschpreis),
      email: emailInput || 'lena@mail.ch',
      status: 'Aktiv'
    };
    
    // Check if duplicate, replace or append
    setAlarms(prev => {
      const filtered = prev.filter(a => a.productName !== 'Sofa Lena 3-Sitzer');
      return [newAlarm, ...filtered];
    });

    // Advance to screen 5
    setActiveScreen(5);
    setNotification('PriceAlarm erfolgreich aktiviert!');
  };

  // Direct buy simulation
  const handleDirectBuy = () => {
    setActiveScreen(5);
    setNotification('Weiterleitung zu IKEA.ch gestartet!');
  };

  // Internal report simulation
  const handleInternalReport = () => {
    setActiveScreen(5);
    setNotification('Preisdifferenz an QS-Team übermittelt! Vielen Dank.');
  };

  // Get sorted providers based on sorting state
  const getSortedProviders = () => {
    const list = [...PROVIDERS_FOR_SOFA];
    if (sortBy === 'cheapest') {
      return list.sort((a, b) => a.price - b.price);
    } else {
      // Sort newest order (mocked - priority on IKEA/Pfister)
      return list.sort((a, b) => {
        if (a.id === 'ikea') return -1;
        if (b.id === 'ikea') return 1;
        return 0;
      });
    }
  };

  // Quick reset function for tester convenience
  const resetPrototype = () => {
    setActiveScreen(1);
    setSearchQuery('');
    setSelectedCategory(null);
    setSelectedProviderId('ikea');
    setSelectedActionId(2);
    setWunschpreis(680);
    setEmailInput('lena@mail.ch');
    setNotification('Prototyp auf Anfangszustand zurückgesetzt.');
  };

  // Details for current Provider on Screen 3
  const currentProviderDetail = PROVIDER_DETAILS[selectedProviderId] || PROVIDER_DETAILS.ikea;

  return (
    <div className="min-h-screen bg-[#e8edf5] font-sans antialiased py-6 px-4 flex flex-col items-center justify-center relative selection:bg-blue-200">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            className="fixed top-4 z-50 bg-[#0f172a] text-white text-xs px-5 py-3 rounded-full shadow-xl flex items-center space-x-2 border border-slate-700 max-w-sm"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>{notification}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Container: Two columns on desktop, centered single shell on mobile */}
      <div className="w-full max-w-5xl flex flex-col lg:flex-row items-center lg:items-start justify-center gap-8">
        
        {/* Left Side: Desktop Controller Panel & Metainfo */}
        <div className="w-full max-w-[390px] lg:max-w-xs flex flex-col space-y-4 bg-white/70 backdrop-blur-md p-6 rounded-3xl shrink-0 border border-slate-200 shadow-sm text-slate-700">
          <div className="flex items-center space-x-2">
            <div className="bg-[#1a6ef5] text-white p-1.5 rounded-lg">
              <TrendingDown size={20} />
            </div>
            <div>
              <h1 className="font-extrabold text-lg tracking-tight text-slate-900 leading-tight">PriceRadar</h1>
              <p className="text-xs text-slate-400">ÜK Modul 248 Prototyp</p>
            </div>
          </div>

          <div className="text-xs space-y-2 border-t border-slate-200/60 pt-4">
            <p className="font-semibold text-slate-800">💡 Tester-Hinweise & Navigation:</p>
            <p>Dieser klickbare Prototyp simuliert die 5 wesentlichen Phasen der Benutzer-Journey für die Preisüberwachung von Möbelstücken:</p>
            <ul className="list-disc pl-4 space-y-1 text-slate-500">
              <li><button onClick={() => setActiveScreen(1)} className="hover:underline text-left text-blue-600 font-medium">Screen 1: Suche & Kategorien</button></li>
              <li><button onClick={() => { setSearchQuery('Sofa Lena 3-Sitzer'); setActiveScreen(2); }} className="hover:underline text-left text-blue-600 font-medium font-mono text-[11px]">Screen 2: Produkt-Preisvergleich</button></li>
              <li><button onClick={() => { setSelectedProviderId('ikea'); setActiveScreen(3); }} className="hover:underline text-left text-blue-600 font-medium">Screen 3: IKEA Anbieterdetails</button></li>
              <li><button onClick={() => setActiveScreen(4)} className="hover:underline text-left text-blue-600 font-medium">Screen 4: Aktion wählen & Formulare</button></li>
              <li><button onClick={() => setActiveScreen(5)} className="hover:underline text-left text-blue-600 font-medium">Screen 5: Bestätigung</button></li>
            </ul>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
            <div className="flex justify-between text-slate-500">
              <span>Aktiver Alarm:</span>
              <span className="font-semibold text-emerald-600">CHF {wunschpreis}.–</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>E-Mail:</span>
              <span className="font-mono text-slate-800 truncate max-w-[140px]">{emailInput}</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>Simulierte Alarme:</span>
              <span className="bg-slate-200 px-1.5 py-0.5 rounded text-[10px] text-slate-700 font-semibold">{alarms.length}</span>
            </div>
          </div>

          <div className="pt-2 flex gap-2">
            <button 
              onClick={resetPrototype}
              className="w-full bg-slate-800 hover:bg-slate-900 text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
              id="btn-reset-prototype"
            >
              <Undo2 size={14} />
              <span>Reset Prototyp</span>
            </button>
            
            <button 
              onClick={() => setShowAlarmsSheet(true)}
              className="bg-white hover:bg-slate-50 text-slate-800 rounded-xl py-2 px-3 text-xs font-semibold border border-slate-200 flex items-center justify-center transition-all shadow-sm"
              id="btn-show-alarms"
              title="Alarme anzeigen"
            >
              <Bell size={14} className="text-yellow-500 animate-swing" />
              <span className="ml-1 text-[11px] font-bold">({alarms.length})</span>
            </button>
          </div>
        </div>

        {/* CENTER COLUMN: The smartphone shell frame & indicator dots */}
        <div className="flex flex-col items-center">
          
          {/* Smartphone Hardware Frame Body */}
          <div 
            className="w-[390px] h-[785px] bg-[#0f172a] rounded-[52px] p-[11px] shadow-[0_25px_60px_-15px_rgba(15,23,42,0.4)] relative border-4 border-slate-800 flex flex-col justify-between"
            style={{ contentVisibility: 'auto' }}
          >
            {/* Front Camera & Speaker Notch (Dynamic Island Accent) */}
            <div className="absolute top-[18px] left-1/2 -translate-x-1/2 w-[110px] h-[26px] bg-black rounded-full z-40 flex items-center justify-between px-3">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-900/60 shadow-[inset_0_1px_2px_rgba(255,255,255,0.2)]"></div>
              <div className="w-14 h-1 bg-neutral-900 rounded-full"></div>
              <div className="w-2 h-2 rounded-full bg-blue-950 border border-blue-900/40"></div>
            </div>

            {/* Inner AMOLED Screen Display Container */}
            <div className="w-full h-full bg-[#e8edf5] rounded-[42px] overflow-hidden relative flex flex-col justify-between select-none border border-black/40">
              
              {/* STATUS BAR (9:01 | Carrier 📶 Battery 🔋) */}
              <div className="bg-[#0f172a] text-slate-200 text-[11px] font-semibold px-6 pt-3 pb-2 flex justify-between items-center z-30 shrink-0">
                <span className="font-mono tracking-tight text-slate-100">9:01</span>
                
                {/* Visual Gap for Notch/Dynamic Island spacer */}
                <div className="w-20"></div>

                <div className="flex items-center space-x-1.5 text-[10px]">
                  <span>5G</span>
                  <span className="tracking-widest">📶</span>
                  <div className="w-5 h-2.5 bg-slate-700/50 rounded-sm p-[1px] relative flex">
                    <div className="bg-emerald-400 h-full w-[85%] rounded-[1px]"></div>
                    <span className="absolute -right-[2px] top-1/2 -translate-y-1/2 w-[2px] h-[3px] bg-slate-600 rounded-r-sm"></span>
                  </div>
                </div>
              </div>

              {/* DYNAMIC SCREEN VIEWPORT */}
              <div className="flex-1 w-full overflow-y-auto block relative bg-[#e8edf5]">
                <AnimatePresence mode="wait">
                  
                  {/* SCREEN 1: HOME / SEARCH */}
                  {activeScreen === 1 && (
                    <motion.div
                      key="screen1"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 15 }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col min-h-full pb-16"
                    >
                      {/* Dark Navy Header */}
                      <div className="bg-[#0f172a] text-white px-5 pt-4 pb-8 rounded-b-[28px] shadow-md relative overflow-hidden">
                        {/* Background subtle mesh network blobs */}
                        <div className="absolute right-0 top-0 w-24 h-24 bg-blue-500/10 rounded-full blur-xl"></div>
                        <div className="absolute left-10 -bottom-10 w-32 h-32 bg-[#1a6ef5]/10 rounded-full blur-2xl"></div>

                        <div className="relative z-10 space-y-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-1">
                              <span className="text-lg">🏠</span>
                              <h2 className="text-base font-bold tracking-tight">Home / Suche</h2>
                            </div>
                            <span className="text-[10px] bg-blue-500/30 text-blue-200 px-2 py-0.5 rounded-full font-semibold border border-blue-500/20 font-mono">PROTOTYP</span>
                          </div>
                          <p className="text-xs text-slate-300">Produkt suchen oder Kategorie wählen</p>
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="px-4 -mt-5 space-y-5 relative z-10">
                        
                        {/* Interactive Search Container */}
                        <form onSubmit={handleSearchSubmit} className="bg-white p-3 rounded-2xl shadow-lg border border-slate-100 flex items-center space-x-2">
                          <div className="text-slate-400 p-1">
                            <Search size={18} />
                          </div>
                          <input 
                            type="text"
                            placeholder="z.B. «Sofa Lena 3-Sitzer»"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onClick={() => {
                              // If empty, auto fill to show cool reactive search
                              if (!searchQuery) setSearchQuery('Sofa Lena 3-Sitzer');
                            }}
                            className="bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none flex-1 font-medium"
                            id="field-search-input"
                          />
                          {searchQuery && (
                            <button 
                              type="button" 
                              onClick={() => setSearchQuery('')}
                              className="text-[10px] font-bold text-slate-400 hover:text-slate-600 bg-slate-100 rounded-full w-5 h-5 flex items-center justify-center shrink-0"
                            >
                              ✕
                            </button>
                          )}
                        </form>

                        {/* Category Grid 2x2 */}
                        <div className="space-y-2">
                          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">Kategorien</h3>
                          
                          <div className="grid grid-cols-2 gap-3">
                            {CATEGORIES.map((cat) => (
                              <button
                                key={cat.id}
                                type="button"
                                onClick={() => selectCategory(cat.id)}
                                className={`p-3.5 bg-white rounded-2xl border text-left hover:scale-[1.02] transform transition-all shadow-sm group duration-150 ${selectedCategory === cat.id ? 'border-[#1a6ef5] bg-blue-50/20 ring-1 ring-blue-500/20' : 'border-slate-200/80'}`}
                                id={`cat-btn-${cat.id}`}
                              >
                                <div className="flex justify-between items-start mb-1">
                                  <span className="text-2xl group-hover:scale-110 transition-transform duration-150 inline-block">{cat.icon}</span>
                                  <span className="text-[10px] text-slate-400 font-semibold font-mono bg-slate-100 px-1.5 py-0.5 rounded-md">{cat.count} Prods</span>
                                </div>
                                <span className="text-xs font-bold text-slate-900 block group-hover:text-[#1a6ef5]">{cat.name}</span>
                                <span className="text-[9px] text-slate-400 block mt-0.5 font-medium">Anbieter scannen</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* "Zuletzt gesucht" section */}
                        <div className="space-y-2">
                          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">Zuletzt gesucht</h3>
                          
                          <div 
                            onClick={() => {
                              setSearchQuery('Sofa Lena 3-Sitzer');
                              setActiveScreen(2);
                              triggerCelebratoryLog('Navigiert über zuletzt gesucht Sofa Lena');
                            }}
                            className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-sm hover:border-[#1a6ef5]/50 cursor-pointer transition-all flex items-center justify-between group"
                            id="recent-search-row"
                          >
                            <div className="space-y-1">
                              <p className="text-xs font-bold text-slate-900 group-hover:text-[#1a6ef5] flex items-center">
                                Sofa Lena 3-Sitzer
                                <span className="ml-2 w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block animate-pulse"></span>
                              </p>
                              <p className="text-[10px] text-slate-400 font-medium">Zuletzt: heute 08:32 · <span className="font-semibold text-slate-500">IKEA Bestpreis</span></p>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <span className="text-[10px] bg-blue-50 text-blue-600 px-2 py-1 rounded-lg font-bold border border-blue-100">
                                4 Anbieter
                              </span>
                              <ChevronLeft size={16} className="rotate-180 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                            </div>
                          </div>
                        </div>

                        {/* Grosser Suchbutton */}
                        <button
                          type="button"
                          onClick={() => {
                            if (!searchQuery) {
                              setSearchQuery('Sofa Lena 3-Sitzer');
                            }
                            setActiveScreen(2);
                            triggerCelebratoryLog('Suchen-Button gedrückt');
                          }}
                          className="w-full bg-[#0f172a] hover:bg-slate-900 text-white font-bold text-xs py-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-lg transition-transform hover:scale-[1.01] active:scale-[0.99]"
                          id="btn-main-search"
                        >
                          <span>Suchen</span>
                          <Search size={14} className="stroke-[3]" />
                        </button>

                      </div>
                    </motion.div>
                  )}

                  {/* SCREEN 2: PREISVERGLEICH */}
                  {activeScreen === 2 && (
                    <motion.div
                      key="screen2"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 15 }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col min-h-full pb-16"
                    >
                      {/* Dark Navy Header */}
                      <div className="bg-[#0f172a] text-white px-4 pt-3 pb-5 rounded-b-[24px] shadow-md relative shrink-0">
                        <div className="flex items-center justify-between mb-3">
                          <button 
                            onClick={() => setActiveScreen(1)} 
                            className="text-slate-300 hover:text-white px-2.5 py-1.5 bg-slate-800/60 rounded-xl flex items-center text-xs font-semibold backdrop-blur-sm shadow-sm transition-all"
                            id="btn-back-to-s1"
                          >
                            <ChevronLeft size={16} className="mr-0.5 -ml-1 text-slate-300" />
                            Zurück
                          </button>
                          
                          <span className="text-[10px] bg-[#1a6ef5] text-white px-2.5 py-0.5 rounded-full font-bold border border-blue-400/20">
                            4 Treffer
                          </span>
                        </div>

                        <div className="space-y-1 px-1">
                          <div className="flex items-center space-x-1.5">
                            <span className="text-base">📊</span>
                            <h2 className="text-sm font-extrabold tracking-tight">Preisvergleich</h2>
                          </div>
                          <p className="text-xs font-mono font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded inline-block">
                            «{searchQuery || "Sofa Lena 3-Sitzer"}»
                          </p>
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="px-4 py-4 space-y-4">
                        
                        {/* Oranges Warn-Banner */}
                        <div className="bg-orange-50 border border-orange-200/80 rounded-2xl p-3.5 flex items-start space-x-2.5 shadow-sm">
                          <span className="text-base mt-0.5 shrink-0">⚠️</span>
                          <div>
                            <p className="text-[11px] font-bold text-orange-850 leading-snug">Conforma-Preis: vor 3 Tagen – bitte prüfen!</p>
                            <p className="text-[9px] text-orange-700 font-medium mt-0.5">Letzter automatischer Crawler-Lauf meldete Abweichungen.</p>
                          </div>
                        </div>

                        {/* Sortier-Buttons */}
                        <div className="flex justify-between items-center bg-white/70 p-1.5 rounded-xl border border-slate-200/60 shadow-sm">
                          <span className="text-[10px] font-bold text-slate-400 ml-2 uppercase tracking-wider">Ergebnisse sortieren</span>
                          <div className="flex space-x-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => setSortBy('cheapest')}
                              className={`text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all ${sortBy === 'cheapest' ? 'bg-[#0f172a] text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                            >
                              Günstigster
                            </button>
                            <button
                              type="button"
                              onClick={() => setSortBy('newest')}
                              className={`text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all ${sortBy === 'newest' ? 'bg-[#0f172a] text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                            >
                              Aktuellste
                            </button>
                          </div>
                        </div>

                        {/* Provider cards (clickable -> Screen 3) */}
                        <div className="space-y-3">
                          {getSortedProviders().map((prov) => {
                            const isBest = prov.id === 'ikea';
                            const isConforma = prov.id === 'conforma';
                            const isPfister = prov.id === 'pfister';
                            
                            return (
                              <div
                                key={prov.id}
                                onClick={() => {
                                  setSelectedProviderId(prov.id);
                                  setActiveScreen(3);
                                  triggerCelebratoryLog(`Provider ausgewählt: ${prov.name}`);
                                }}
                                className={`bg-white p-3.5 rounded-2xl border cursor-pointer hover:scale-[1.01] hover:-translate-y-0.5 active:scale-100 shadow-sm hover:shadow-md transition-all flex flex-col space-y-2 relative group overflow-hidden ${
                                  isBest ? 'border-emerald-500 ring-1 ring-emerald-500/10' : 
                                  isConforma ? 'border-orange-500/80 ring-1 ring-orange-500/10' : 
                                  isPfister ? 'border-rose-400/40 hover:border-rose-500' : 'border-slate-200'
                                }`}
                                id={`prov-card-${prov.id}`}
                              >
                                {/* Decorative badge or accent strip inside */}
                                {prov.badge && (
                                  <div className="absolute right-0 top-0 text-[8px] tracking-wider font-extrabold uppercase px-2.5 py-1 rounded-bl-xl shadow-xs bg-emerald-500 text-white flex items-center space-x-1">
                                    <span>{prov.badge}</span>
                                  </div>
                                )}

                                {isConforma && (
                                  <div className="absolute right-0 top-0 text-[8px] tracking-wider font-extrabold uppercase px-2.5 py-1 rounded-bl-xl shadow-xs bg-orange-500 text-white">
                                    <span>⚠️ VERZÖGERT</span>
                                  </div>
                                )}

                                <div className="flex justify-between items-start">
                                  <div className="space-y-0.5">
                                    <h4 className="text-xs font-bold text-slate-900 group-hover:text-[#1a6ef5] flex items-center">
                                      {prov.name}
                                      <span className="ml-1.5 text-[9px] font-mono text-slate-400 font-normal">({prov.domain})</span>
                                    </h4>
                                    <p className="text-[10px] text-slate-400 font-medium font-mono">
                                      {prov.timestamp} · {prov.domain}
                                    </p>
                                  </div>

                                  <div className="text-right">
                                    <p className={`text-sm font-extrabold font-mono tracking-tight ${
                                      isBest ? 'text-emerald-600' : 
                                      isPfister ? 'text-rose-600' : 'text-slate-800'
                                    }`}>
                                      CHF {prov.price}.–
                                    </p>
                                    <p className="text-[8px] text-slate-400 font-semibold font-mono">Inkl. MwSt.</p>
                                  </div>
                                </div>

                                <div className="border-t border-slate-100 pt-2/5 flex justify-between items-center text-[9px] text-slate-400 font-medium">
                                  <span>ℹ️ Tippen für Verlauf & Action</span>
                                  <span className="text-[#1a6ef5] font-bold group-hover:translate-x-0.5 transition-transform flex items-center">
                                    Auswählen <ChevronLeft size={10} className="rotate-180 ml-0.5 text-blue-500" />
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Reset / back to search bottom panel */}
                        <div className="text-center pt-2">
                          <p className="text-[10px] text-slate-400 font-semibold font-mono">Wende dich an den Support für zusätzliche Möbelcrawler.</p>
                        </div>

                      </div>
                    </motion.div>
                  )}

                  {/* SCREEN 3: ANBIETER-DETAIL */}
                  {activeScreen === 3 && (
                    <motion.div
                      key="screen3"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 15 }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col min-h-full pb-16"
                    >
                      {/* Dark Green Brand Header or Selected Vendor's themed header */}
                      <div className={`${currentProviderDetail.colorTheme} text-white px-4 pt-3 pb-5 rounded-b-[24px] shadow-md relative transition-colors duration-200`}>
                        <div className="flex items-center justify-between mb-3">
                          <button 
                            onClick={() => setActiveScreen(2)} 
                            className="text-white/85 hover:text-white px-2.5 py-1.5 bg-white/10 rounded-xl flex items-center text-xs font-semibold backdrop-blur-md shadow-sm transition-all"
                            id="btn-back-to-s2"
                          >
                            <ChevronLeft size={16} className="mr-0.5 -ml-1 text-white" />
                            Sofa Lena
                          </button>
                          
                          <span className="text-[9px] tracking-wider font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-white/20 font-mono">
                            Detailansicht
                          </span>
                        </div>

                        <div className="space-y-1">
                          <p className="text-[10px] text-white/70 font-semibold uppercase tracking-wider">{currentProviderDetail.shopName}</p>
                          <h2 className="text-xl font-black tracking-tight font-mono">
                            CHF {currentProviderDetail.price}.–
                          </h2>
                          <div className="flex justify-between items-center text-xs text-white/90">
                            <p className="font-semibold line-clamp-1">{currentProviderDetail.productTitle}</p>
                          </div>
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="px-4 py-4 space-y-4">
                        
                        {/* Quelle & Aktualität Info Card */}
                        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                          <div className="flex items-center space-x-1">
                            <span className="text-xs">📋</span>
                            <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">Quelle & Aktualität</h3>
                          </div>

                          <div className="text-xs space-y-2 pt-1 border-t border-slate-100">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400 font-medium">Link:</span>
                              <a 
                                href="#fake-link" 
                                className="text-blue-500 font-semibold flex items-center hover:underline truncate max-w-[200px]"
                                onClick={(e) => {
                                  e.preventDefault();
                                  setNotification('Demosite: realer Shop-Link simuliert.');
                                }}
                              >
                                {currentProviderDetail.url}
                                <ExternalLink size={10} className="ml-1" />
                              </a>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-400 font-medium">Letzter Scan:</span>
                              <span className="font-mono font-bold text-slate-800">
                                {currentProviderDetail.timeText}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-400 font-medium">Status:</span>
                              <div className="flex items-center space-x-1 bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full border border-emerald-100 font-bold text-[10px]">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                <span>Daten aktuell</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Preisverlauf (7 Tage) Card */}
                        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-1">
                              <span className="text-xs">📈</span>
                              <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">Preisverlauf (7 Tage)</h3>
                            </div>
                          </div>

                          {/* SVG / Flex Bar Chart */}
                          <div className="h-28 flex items-end justify-between px-2 pt-4 pb-2 border-b border-slate-100/80">
                            {[
                              { day: 'Mo', price: 749, height: 'h-16' },
                              { day: 'Di', price: 749, height: 'h-16' },
                              { day: 'Mi', price: 749, height: 'h-16' },
                              { day: 'Do', price: 749, height: 'h-16' },
                              { day: 'Fr', price: 749, height: 'h-16' },
                              { day: 'Sa', price: 749, height: 'h-16' },
                              { day: 'So', price: 749, height: 'h-16', active: true },
                            ].map((item, index) => (
                              <div key={index} className="flex flex-col items-center space-y-1.5 flex-1 select-none">
                                <div className="text-[8px] font-bold text-slate-400 font-mono">
                                  {item.price}
                                </div>
                                <div className="w-6 relative group flex justify-center">
                                  {/* Bar graphic */}
                                  <div className={`w-3.5 rounded-t-sm transition-all duration-300 ${
                                    item.active 
                                      ? 'bg-blue-600 shadow-xs' 
                                      : 'bg-slate-200 hover:bg-slate-300'
                                  } ${item.height}`}></div>
                                </div>
                                <div className="text-[10px] font-semibold text-slate-500">
                                  {item.day}
                                </div>
                              </div>
                            ))}
                          </div>

                          <div className="flex items-center space-x-1.5 bg-emerald-50 text-emerald-800 p-2.5 rounded-xl border border-emerald-100 text-[11px] font-bold">
                            <span>✅</span>
                            <span>{currentProviderDetail.chartLabel}</span>
                          </div>
                        </div>

                        {/* Grosser grüner Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setActiveScreen(4);
                            triggerCelebratoryLog('In Screen 4 gewechselt');
                          }}
                          className="w-full bg-[#16a34a] hover:bg-emerald-700 text-white font-extrabold text-xs py-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-lg transition-transform hover:scale-[1.01] active:scale-[0.99]"
                          id="btn-goto-s4"
                        >
                          <span>→ Zum Angebot</span>
                        </button>

                      </div>
                    </motion.div>
                  )}

                  {/* SCREEN 4: AKTION WÄHLEN */}
                  {activeScreen === 4 && (
                    <motion.div
                      key="screen4"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 15 }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col min-h-full pb-16"
                    >
                      {/* Dark Red/Orange Header */}
                      <div className="bg-[#7c2d12] text-white px-4 pt-3 pb-5 rounded-b-[24px] shadow-md shrink-0">
                        <div className="flex justify-between items-center mb-3">
                          <button 
                            onClick={() => {
                              setActiveScreen(3);
                            }} 
                            className="text-white/85 hover:text-white px-2.5 py-1.5 bg-white/10 rounded-xl flex items-center text-xs font-semibold backdrop-blur-md shadow-sm transition-all"
                            id="btn-back-to-s3"
                          >
                            <ChevronLeft size={16} className="mr-0.5 -ml-1 text-white" />
                            IKEA Detail
                          </button>
                          
                          <span className="text-[9px] tracking-wider font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-white/20 font-mono">
                            Aktion
                          </span>
                        </div>

                        <div className="space-y-0.5">
                          <div className="flex items-center space-x-1">
                            <span className="text-sm">⚡</span>
                            <h2 className="text-base font-extrabold tracking-tight">Aktion wählen</h2>
                          </div>
                          <p className="text-xs text-orange-200">Was möchtest du tun?</p>
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="px-4 py-4 space-y-4">
                        
                        {/* The 3 Action Cards list */}
                        <div className="space-y-2.5">
                          
                          {/* CARD 1: Direkt kaufen */}
                          <div
                            onClick={() => {
                              setSelectedActionId(1);
                              triggerCelebratoryLog('Selected Card: Direkt kaufen');
                            }}
                            className={`p-3.5 rounded-2xl bg-white border cursor-pointer transition-all flex items-start space-x-3 shadow-xs ${
                              selectedActionId === 1 ? 'border-blue-600 ring-1 ring-blue-100 bg-blue-50/10' : 'border-slate-200 hover:border-slate-300'
                            }`}
                            id="action-card-1"
                          >
                            <div className="p-2 bg-blue-50 text-[#1a6ef5] rounded-xl font-bold text-base shrink-0 mt-0.5">
                              🛒
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-xs font-extrabold text-slate-800">Direkt kaufen</p>
                              <p className="text-[10px] text-slate-400 font-medium">Weiterleitung zu IKEA.ch</p>
                            </div>
                          </div>

                          {/* CARD 2: Preisalarm setzen (Vorausgewählt) */}
                          <div
                            onClick={() => {
                              setSelectedActionId(2);
                              triggerCelebratoryLog('Selected Card: Preisalarm setzen');
                            }}
                            className={`p-3.5 rounded-2xl bg-white border cursor-pointer transition-all flex items-start space-x-3 shadow-xs ${
                              selectedActionId === 2 ? 'border-blue-600 ring-1 ring-blue-100 bg-blue-50/10' : 'border-slate-200 hover:border-slate-300'
                            }`}
                            id="action-card-2"
                          >
                            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl font-bold text-base shrink-0 mt-0.5">
                              🔔
                            </div>
                            <div className="space-y-0.5 flex-1">
                              <div className="flex justify-between items-center">
                                <p className="text-xs font-extrabold text-slate-800">Preisalarm setzen</p>
                                <span className="text-[8px] bg-blue-100 text-blue-700 font-extrabold px-1.5 py-0.5 rounded">AKTIV</span>
                              </div>
                              <p className="text-[10px] text-slate-400 font-medium">E-Mail bei Unterschreitung des Wunschpreises</p>
                            </div>
                          </div>

                          {/* CARD 3: Intern melden */}
                          <div
                            onClick={() => {
                              setSelectedActionId(3);
                              triggerCelebratoryLog('Selected Card: Intern melden');
                            }}
                            className={`p-3.5 rounded-2xl bg-white border cursor-pointer transition-all flex items-start space-x-3 shadow-xs ${
                              selectedActionId === 3 ? 'border-blue-600 ring-1 ring-blue-100 bg-blue-50/10' : 'border-slate-200 hover:border-slate-300'
                            }`}
                            id="action-card-3"
                          >
                            <div className="p-2 bg-[#7c2d12]/10 text-[#7c2d12] rounded-xl font-bold text-base shrink-0 mt-0.5">
                              📋
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-xs font-extrabold text-slate-800">Intern melden</p>
                              <p className="text-[10px] text-slate-400 font-medium">Preisdifferenz ans Team senden</p>
                            </div>
                          </div>

                        </div>

                        {/* Dynamic Interactive Panel depending on selected card */}
                        <AnimatePresence mode="wait">
                          {selectedActionId === 2 && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-4"
                            >
                              <div className="border-b border-slate-100 pb-2">
                                <p className="text-xs font-black text-slate-800 uppercase tracking-wider">Alarmdaten konfigurieren</p>
                              </div>

                              <div className="space-y-3">
                                {/* Wunschpreis Input */}
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold uppercase text-slate-400 block">Wunschpreis CHF</label>
                                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between">
                                    <div className="flex items-center space-x-2">
                                      <span className="font-bold text-slate-400">CHF</span>
                                      <input 
                                        type="number"
                                        value={wunschpreis}
                                        onChange={(e) => setWunschpreis(Number(e.target.value))}
                                        className="bg-transparent font-extrabold text-sm text-slate-800 focus:outline-none w-24 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                        id="input-wunschpreis"
                                      />
                                    </div>
                                    <div className="flex space-x-1">
                                      <button 
                                        type="button"
                                        onClick={() => {
                                          setWunschpreis(prev => Math.max(10, prev - 20));
                                          triggerCelebratoryLog('Wunschpreis verringert');
                                        }}
                                        className="bg-slate-200 text-slate-700 w-6 h-6 rounded-md hover:bg-slate-300 font-bold text-xs"
                                      >
                                        -
                                      </button>
                                      <button 
                                        type="button"
                                        onClick={() => {
                                          setWunschpreis(prev => prev + 20);
                                          triggerCelebratoryLog('Wunschpreis erhöht');
                                        }}
                                        className="bg-slate-200 text-slate-700 w-6 h-6 rounded-md hover:bg-slate-300 font-bold text-xs"
                                      >
                                        +
                                      </button>
                                    </div>
                                  </div>
                                  <span className="text-[8px] text-slate-400 block font-medium">Bester gefundener Preis ist CHF 749.–</span>
                                </div>

                                {/* E-Mail Input */}
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold uppercase text-slate-400 block">E-Mail für Benachrichtigung</label>
                                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center space-x-2">
                                    <Mail size={14} className="text-slate-400" />
                                    <input 
                                      type="email"
                                      value={emailInput}
                                      onChange={(e) => setEmailInput(e.target.value)}
                                      placeholder="wunsch@mail.ch"
                                      className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none flex-1"
                                      id="input-email"
                                    />
                                  </div>
                                </div>
                              </div>

                              <button 
                                onClick={handleSaveAlarm}
                                className="w-full bg-[#1a6ef5] hover:bg-blue-700 text-white font-extrabold text-xs py-3 rounded-xl shadow-md transition-all active:scale-[0.98] flex items-center justify-center space-x-1.5"
                                id="btn-submit-alarm"
                              >
                                <span>Alarm aktivieren →</span>
                              </button>
                            </motion.div>
                          )}

                          {selectedActionId === 1 && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3"
                            >
                              <div className="flex items-center space-x-2 text-slate-800">
                                <span className="text-xl">👉</span>
                                <h3 className="text-xs font-bold uppercase text-slate-800 tracking-wider">Weiterleitung zu IKEA</h3>
                              </div>
                              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                                Du wirst in einem neuen Tab zum verifiziert sichersten und günstigsten Partnershop geleitet (ikea.com).
                              </p>
                              <button 
                                onClick={handleDirectBuy}
                                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-xl shadow-md transition-all active:scale-[0.98]"
                                id="btn-submit-buy"
                              >
                                Jetzt weiterleiten ⚡
                              </button>
                            </motion.div>
                          )}

                          {selectedActionId === 3 && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3"
                            >
                              <div className="flex items-center space-x-2 text-slate-800">
                                <span className="text-xl">📢</span>
                                <h3 className="text-xs font-bold uppercase text-slate-800 tracking-wider">QS Abweichung melden</h3>
                              </div>
                              <p className="text-xs text-slate-500 leading-relaxed">
                                Melde fehlerhafte Preise an das Pfister & IKEA Erfassungsteam, um die Crawler-Filter zu korrigieren.
                              </p>
                              <button 
                                onClick={handleInternalReport}
                                className="w-full bg-[#7c2d12] hover:bg-[#9a3412] text-white font-extrabold text-xs py-3 rounded-xl shadow-md transition-all active:scale-[0.98]"
                                id="btn-submit-report"
                              >
                                Preisprüfung einleiten ✓
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {/* Oranger Warn-Kasten am unteren Rand */}
                        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 flex items-start space-x-3 shadow-xs">
                          <span className="text-lg shrink-0">⚠️</span>
                          <div>
                            <p className="text-[11px] font-black text-slate-900 leading-tight">Pfister-Preis ist 20% höher als IKEA – melden lohnt sich!</p>
                            <p className="text-[10px] text-slate-500 mt-1 font-medium">Spannweiten über CHF 150 für identische Artikel registriert. Nutze unsere Alarme.</p>
                          </div>
                        </div>

                      </div>
                    </motion.div>
                  )}

                  {/* SCREEN 5: BESTÄTIGUNG */}
                  {activeScreen === 5 && (
                    <motion.div
                      key="screen5"
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 15 }}
                      transition={{ duration: 0.18 }}
                      className="flex flex-col min-h-full pb-16"
                    >
                      {/* Purple Gradient Header */}
                      <div className="bg-gradient-to-r from-[#1e1b4b] to-[#312e81] text-white px-5 pt-6 pb-6 rounded-b-[24px] shadow-md text-center shrink-0">
                        <div className="space-y-2">
                          <span className="text-5xl block animate-bounce">🎉</span>
                          <h2 className="text-lg font-black tracking-tight">
                            {selectedActionId === 2 ? 'Preisalarm gesetzt!' : 
                             selectedActionId === 1 ? 'Weiterleitung bereit!' : 'Differenz gemeldet!'}
                          </h2>
                          <p className="text-xs text-slate-300">
                            {selectedActionId === 2 ? 'Du wirst benachrichtigt, sobald der Preis fällt' : 
                             selectedActionId === 1 ? 'Simulation für Partnershop gestartet' : 'Das QS-Team prüft das Inserat'}
                          </p>
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="px-4 py-4 space-y-4">
                        
                        {/* Green confirmation card "Dein Alarm" or action status */}
                        <div className="bg-emerald-50 border border-emerald-200/90 rounded-2xl p-4.5 space-y-3 shadow-xs">
                          <div className="flex items-center space-x-1.5">
                            <span className="text-emerald-700">✅</span>
                            <h3 className="text-xs font-black uppercase text-emerald-800 tracking-wider">
                              {selectedActionId === 2 ? 'Dein aktiver Alarm:' : 'Aktionsparameter:'}
                            </h3>
                          </div>

                          <div className="text-xs space-y-2.5 pt-2 border-t border-emerald-200/40">
                            <div>
                              <p className="text-[10px] text-emerald-600 font-semibold uppercase font-mono">Produkt</p>
                              <p className="font-extrabold text-[#0f172a]">Sofa Lena 3-Sitzer</p>
                            </div>

                            {selectedActionId === 2 ? (
                              <>
                                <div>
                                  <p className="text-[10px] text-emerald-600 font-semibold uppercase font-mono">Wunschpreis</p>
                                  <p className="font-black text-slate-900 text-sm font-mono">CHF {wunschpreis}.–</p>
                                </div>

                                <div>
                                  <p className="text-[10px] text-emerald-600 font-semibold uppercase font-mono">Benachrichtigungs-Empfänger</p>
                                  <p className="font-bold text-slate-800 font-mono break-all">{emailInput || 'lena@mail.ch'}</p>
                                </div>
                              </>
                            ) : (
                              <div>
                                <p className="text-[10px] text-emerald-600 font-semibold uppercase font-mono">Shop-Ziel</p>
                                <p className="font-black text-slate-900 font-mono">IKEA Schweiz (CHF 749.–)</p>
                              </div>
                            )}

                            <div className="flex items-center justify-between pt-1">
                              <span className="text-[10px] text-emerald-600 font-semibold uppercase font-mono">Status</span>
                              <div className="bg-emerald-700 text-white rounded-md px-2.5 py-0.5 text-[9px] font-black tracking-wider uppercase flex items-center space-x-1">
                                <span className="w-1.5 h-1.5 bg-emerald-300 rounded-full animate-ping"></span>
                                <span>Aktiv</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Yellow Tip Card */}
                        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start space-x-3 shadow-xs">
                          <span className="text-lg shrink-0">💡</span>
                          <div>
                            <p className="text-[11px] font-black text-amber-900 leading-tight">Preistipp:</p>
                            <p className="text-[10px] text-slate-600 mt-1 leading-relaxed font-semibold">
                              IKEA hat in den letzten 30 Tagen 2x den Preis gesenkt – eine weitere Senkung ist statistisch wahrscheinlich.
                            </p>
                          </div>
                        </div>

                        {/* Bottom Action buttons */}
                        <div className="space-y-2 pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedCategory(null);
                              setSearchQuery('');
                              setActiveScreen(1);
                              triggerCelebratoryLog('Zurück zur Suche');
                            }}
                            className="w-full bg-[#0f172a] hover:bg-slate-900 text-white font-extrabold text-xs py-3.5 rounded-2xl flex items-center justify-center space-x-1 shadow-lg transition-transform hover:scale-[1.01]"
                            id="btn-new-search"
                          >
                            <Search size={14} />
                            <span>← Neue Suche</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setShowAlarmsSheet(true);
                              triggerCelebratoryLog('Meine Alarme Modal gestartet');
                            }}
                            className="w-full bg-white hover:bg-slate-50 text-slate-800 font-extrabold text-xs py-3.5 rounded-2xl border border-slate-200 flex items-center justify-center transition-transform hover:scale-[1.01]"
                            id="btn-show-alarms-bottom"
                          >
                            <Bell size={13} className="mr-1.5 text-amber-500" />
                            <span>Meine Alarme anzeigen</span>
                          </button>
                        </div>

                      </div>
                    </motion.div>
                  )}

                </AnimatePresence>
              </div>

              {/* BOTTOM NAVIGATION TAB BAR (Home, Suche, Alarme, Einstellungen) */}
              <div className="bg-[#0f172a] border-t border-slate-800 text-xs py-1.5 px-4 flex justify-around items-center shrink-0 z-30 shadow-[0_-5px_15px_rgba(0,0,0,0.2)]">
                
                {/* Navigation item 1: Home/Search */}
                <button 
                  type="button"
                  onClick={() => {
                    setActiveScreen(1);
                    triggerCelebratoryLog('Tab: Home/Suche geklickt');
                  }}
                  className={`flex flex-col items-center space-y-0.5 filter transition-all ${
                    activeScreen === 1 ? 'text-[#1a6ef5] scale-105' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  id="tab-btn-home"
                >
                  <Home size={18} className={activeScreen === 1 ? 'stroke-[2.5]' : 'stroke-[1.8]'} />
                  <span className="text-[9px] font-bold">Home</span>
                </button>

                {/* Navigation item 2: Search Listing / Results (Screen 2) */}
                <button 
                  type="button"
                  onClick={() => {
                    setActiveScreen(2);
                    triggerCelebratoryLog('Tab: Suche-Details geklickt');
                  }}
                  className={`flex flex-col items-center space-y-0.5 filter transition-all ${
                    activeScreen === 2 ? 'text-[#1a6ef5] scale-105' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  id="tab-btn-search"
                >
                  <Search size={18} className={activeScreen === 2 ? 'stroke-[2.5]' : 'stroke-[1.8]'} />
                  <span className="text-[9px] font-bold">Suche</span>
                </button>

                {/* Navigation item 3: Alarme (Opens Alarms overlay sheet!) */}
                <button 
                  type="button"
                  onClick={() => {
                    setShowAlarmsSheet(true);
                    triggerCelebratoryLog('Tab: Alarme geklickt');
                  }}
                  className={`flex flex-col items-center space-y-0.5 relative filter transition-all text-slate-400 hover:text-slate-200`}
                  id="tab-btn-alarms"
                >
                  <div className="relative">
                    <Bell size={18} className="stroke-[1.8]" />
                    <span className="absolute -top-1 -right-1.5 bg-red-500 text-white rounded-full w-3.5 h-3.5 text-[8px] font-extrabold flex items-center justify-center border border-slate-905">
                      {alarms.length}
                    </span>
                  </div>
                  <span className="text-[9px] font-bold">Alarme</span>
                </button>

                {/* Navigation item 4: Einstellungen settings */}
                <button 
                  type="button"
                  onClick={() => {
                    setNotification('Einstellungen-Modul wird für Release ÜK vorbereitet.');
                    triggerCelebratoryLog('Tab: Settings clicked');
                  }}
                  className="flex flex-col items-center space-y-0.5 text-slate-400 hover:text-slate-200"
                  id="tab-btn-settings"
                >
                  <Settings size={18} className="stroke-[1.8]" />
                  <span className="text-[9px] font-bold font-mono">Setup</span>
                </button>

              </div>

              {/* iOS style bottom gesture line indicator decoration */}
              <div className="bg-[#0f172a] pb-1.5 pt-0.5 flex justify-center shrink-0 w-full">
                <div className="w-28 h-1 bg-slate-700 rounded-full"></div>
              </div>

            </div>
          </div>

          {/* PROGRESS NAVIGATION INDICATOR POINTS (Fortschritts-Punkte) */}
          <div className="flex space-x-2.5 mt-4 items-center justify-center bg-white/40 px-4 py-2 rounded-full border border-slate-200 shadow-xs">
            <span className="text-[10px] uppercase font-mono text-slate-400 font-extrabold tracking-wider mr-1">Screens:</span>
            {[1, 2, 3, 4, 5].map((idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setActiveScreen(idx as ScreenId);
                  triggerCelebratoryLog(`Hürdensprung zu Screen ${idx}`);
                }}
                className={`w-3.5 h-3.5 rounded-full font-sans text-[8px] font-extrabold flex items-center justify-center transition-all ${
                  activeScreen === idx 
                    ? 'bg-[#1a6ef5] text-white scale-120 ring-2 ring-blue-300' 
                    : 'bg-slate-300 hover:bg-slate-400 text-slate-600'
                }`}
                title={`Gehe zu Screen ${idx}`}
              >
                {idx}
              </button>
            ))}
          </div>

        </div>

      </div>

      {/* DRAWER LAYER FOR SAVED ALARMS (Meine Alarme anzeigen) */}
      <AnimatePresence>
        {showAlarmsSheet && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAlarmsSheet(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            ></motion.div>

            {/* Modal Body */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl relative z-10 border border-slate-200"
            >
              {/* Header */}
              <div className="bg-[#0f172a] text-white p-5 flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <Bell className="text-yellow-400 animate-pulse" size={20} />
                  <div>
                    <h3 className="font-extrabold text-sm">Meine Preisalarme</h3>
                    <p className="text-[10px] text-slate-400">Preisüberwachungen ÜK Modul 248</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowAlarmsSheet(false)}
                  className="bg-slate-800 text-white hover:bg-slate-700 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                >
                  ✕
                </button>
              </div>

              {/* Action content */}
              <div className="p-5 max-h-[300px] overflow-y-auto space-y-3 bg-slate-50">
                {alarms.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 space-y-2">
                    <p className="text-2xl">📭</p>
                    <p className="text-xs">Keine aktiven Alarme registriert.</p>
                  </div>
                ) : (
                  alarms.map((al, index) => (
                    <div 
                      key={index}
                      className="bg-white border border-slate-200 p-3 rounded-2xl shadow-xs space-y-2 relative"
                    >
                      <button
                        onClick={() => {
                          setAlarms(prev => prev.filter((_, i) => i !== index));
                          setNotification('Alarm erfolgreich gelöscht.');
                        }}
                        className="absolute right-3 top-3 text-[10px] font-bold text-rose-500 hover:text-rose-700 hover:bg-rose-50 px-2 py-1 rounded"
                        title="Alarm löschen"
                      >
                        Löschen
                      </button>

                      <div className="space-y-0.5">
                        <span className="text-[9px] bg-blue-100 text-blue-700 font-extrabold px-1.5 py-0.5 rounded font-mono uppercase">
                          MÖBELALARM
                        </span>
                        <h4 className="text-xs font-black text-slate-850 pt-1">{al.productName}</h4>
                      </div>

                      <div className="text-[11px] grid grid-cols-2 gap-y-1.5 pt-2 border-t border-slate-100 font-semibold text-slate-500">
                        <div>
                          <span className="text-[9px] text-slate-400 block font-normal">Wunschpreis:</span>
                          <span className="font-mono text-slate-900 font-black">CHF {al.targetPrice}.–</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block font-normal">Zielgruppe:</span>
                          <span className="font-mono text-slate-800 truncate block max-w-[100px]" title={al.email}>{al.email}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block font-normal">Intervall:</span>
                          <span className="text-slate-800">2x täglich</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 block font-normal">Status:</span>
                          <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[9px] font-bold inline-block">🟢 {al.status}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer action */}
              <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
                <button
                  onClick={() => {
                    const sampleAlarms: PriceAlert[] = [
                      { productName: 'Sofa Lena 3-Sitzer', targetPrice: 680, email: 'lena@mail.ch', status: 'Aktiv' },
                      { productName: 'Bett Malm 160x200', targetPrice: 240, email: 'sample@mail.ch', status: 'Aktiv' },
                      { productName: 'Esstisch Ingo', targetPrice: 99, email: 'user@test.com', status: 'Aktiv' }
                    ];
                    setAlarms(sampleAlarms);
                    setNotification('Testdaten für Alarme geladen.');
                  }}
                  className="flex-1 border border-slate-200 text-slate-700 py-2.5 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors"
                >
                  Demo laden
                </button>
                <button
                  onClick={() => setShowAlarmsSheet(false)}
                  className="flex-1 bg-[#0f172a] text-white py-2.5 rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors"
                >
                  Schliessen
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FOOTER METADATA INFO */}
      <footer className="mt-8 text-center space-y-1 relative z-10 select-none">
        <p className="text-[11px] text-slate-400 font-bold tracking-wide uppercase font-mono">
          PriceRadar App · ÜK Modul 248 · Eidgenössischer Prototyp
        </p>
        <p className="text-[10px] text-slate-400">
          Entwickelt mit hoher Präzision für den mobilen Browser-Simulator.
        </p>
      </footer>
    </div>
  );
}
