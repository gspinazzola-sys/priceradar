export type ScreenId = 1 | 2 | 3 | 4 | 5;

export interface Category {
  id: string;
  name: string;
  icon: string;
  count: number;
}

export interface Provider {
  id: string;
  name: string;
  price: number;
  originalPriceText?: string;
  url: string;
  domain: string;
  timestamp: string;
  badge?: string;
  badgeType?: 'best' | 'warning' | 'normal' | 'danger';
  borderClass: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  image?: string;
  providersCount: number;
  bestPrice: number;
  lastSearched: string;
}

export interface PriceAlert {
  productName: string;
  targetPrice: number;
  email: string;
  status: 'Aktiv' | 'Inaktiv';
}
